﻿using System;

namespace Das.Views.Styles
{
    public enum StyleSetters
    {
        Margin,
        Padding,
        BorderThickness,

        Font,
        FontName,
        FontSize,
        FontWeight,

        Foreground,
        Background,
        BorderBrush,

        VerticalAlignment,
        HorizontalAlignment
    }
}
