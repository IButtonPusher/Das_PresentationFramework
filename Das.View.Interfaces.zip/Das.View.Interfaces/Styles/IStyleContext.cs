﻿using System;

namespace Das.Views
{
    public interface IStyleContext : IStyleProvider
    {
        IStyle GetStyleForElement(IVisualElement element);

        void RegisterStyle(IStyle style);
    }
}
