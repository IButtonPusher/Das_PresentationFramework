﻿using System;
using Das.Views.Styles;

namespace Das.Views
{
    public interface IStyleProvider
    {
        T GetStyleSetter<T>(StyleSetters setter, IVisualElement element);
    }
}
