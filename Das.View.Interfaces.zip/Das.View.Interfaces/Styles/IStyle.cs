﻿using System;
using Das.Views.Styles;

namespace Das.Views
{
    public interface IStyle
    {
        Object this[StyleSetters setter] { get; }

        Boolean TryGetValue(StyleSetters setter, out Object val);

        //IDictionary<StyleSetters, Object> Setters { get; }
    }
}
