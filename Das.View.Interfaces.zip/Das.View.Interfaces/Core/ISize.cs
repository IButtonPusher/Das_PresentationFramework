﻿using System;

namespace Das.Views
{
    public interface ISize
    {
        Double Width { get; }
        Double Height { get; }
    }
}
