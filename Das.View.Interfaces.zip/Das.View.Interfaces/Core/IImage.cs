﻿using System;

namespace Das.Views
{
    public interface IImage : ISize
    {

    }
}
