﻿using System;

namespace Das.Views
{

    public class Size : IDeepCopyable<Size>, ISize
    {
        public virtual Double Width { get; }
        public virtual Double Height { get; }

        public static Size Empty { get; } = new Size(0, 0);

        protected Size() { }

        public Size(Double width, Double height)
        {
            Width = width;
            Height = height;
        }

        public static Size operator +(Size size, Thickness margin)
        {
            if (margin == null)
                return size.DeepCopy();

            return new Size(size.Width + margin.Left + margin.Right,
                size.Height + margin.Top + margin.Bottom);
        }

        public static Size operator -(Size size, Thickness margin)
        {
            if (margin == null)
                return size.DeepCopy();

            return new Size(size.Width - (margin.Left + margin.Right),
                size.Height - (margin.Top + margin.Bottom));
        }

        public Size DeepCopy() => new Size(Width, Height);

        public Rectangle CenteredIn(Size outerRect)
        {
            var wDiff = (outerRect.Width - Width) / 2;
            var hDiff = (outerRect.Height - Height) / 2;
            return new Rectangle(wDiff, hDiff, Width, Height);
        }

        public override string ToString() => Width + ", " + Height;
    }
}