﻿using System;
// ReSharper disable UnusedMember.Global

namespace Das.Views
{
	public class Rectangle : Size, IDeepCopyable<Rectangle>
    {
		public Rectangle() : this(0,0,0,0)
		{
		}

        private Double _x;
        private Double _y;
        private Double _w;
        private Double _h;

        public Rectangle(Point location, ISize size)
            : this(location.X, location.Y, size.Width, size.Height) { }

        public Rectangle(Rectangle start, Thickness margin)
            : this(start.X + margin.Left, start.Y + margin.Top, 
                  start.Width - (margin.Left + margin.Right),
                  start.Height - (margin.Top + margin.Bottom))
        { }

        public Rectangle(Double x, Double y, Double width, Double height)
        {
            _x = x;
            _y = y;
            _w = width;
            _h = height;
        }

		public Double Top
        {
            get => _y;
            set => _y = value;
        }

        public Double Left
        {
            get => _x;
            set => _x = value;
        }

        public Point BottomRight => new Point(Left + Width, Top + Height);

        public Double Bottom
        {
            get => _y + _h;
            set
            {
                if (value < Top)
                    throw new InvalidOperationException();
                _h = value - _y;
            }
        }

		public Double Right
        {
            get => _x + Size.Width;
            set
            {
                if (value < _x)
                    throw new InvalidOperationException();
                _w = value - _x;
            }
        }

		public Size Size
        {
            get => new Size(_w, _h);
            set
            {
                _w = value.Width;
                _h = value.Height;
            }
        }

//        private Point _location;
        public Point Location
        {
            get => TopLeft;
            set => TopLeft = value;
        }

        public Point TopLeft
        {
            get => new Point(_x,_y);
            set
            {
                _x = value.X;
                _y = value.Y;
            }
        }

		public Double X
        {
            get => _x;
            set => _x = value;
        }

		public Double Y
        {
            get => _y;
            set => _y = value;
        }

        public override Double Width => _w;

        public override Double Height => _h;

        public static Rectangle operator +(Rectangle rect, Thickness margin)
        {
            if (margin == null)
                return rect.DeepCopy();

            return new Rectangle(rect.X, rect.Y, 
                rect.Width - (margin.Left + margin.Right),
                rect.Height - (margin.Top + margin.Bottom));
        }

        public static Rectangle operator +(Rectangle rect, Point location)
        {
            if (location == null)
                return rect.DeepCopy();

            return new Rectangle(rect.X + location.X, rect.Y + location.Y,
                rect.Width, rect.Height);
        }

        public static Rectangle operator +(Rectangle rect, Size size)
        {
            if (size == null)
                return rect.DeepCopy();

            return new Rectangle(rect.X + size.Width, rect.Y + size.Height,
                rect.Width, rect.Height);
        }

        public override string ToString() => $"x: {_x}, y: {_y} w: {_w} h: {_h}";

        public new Rectangle DeepCopy() => new Rectangle(X, Y, Width, Height);
    }
}