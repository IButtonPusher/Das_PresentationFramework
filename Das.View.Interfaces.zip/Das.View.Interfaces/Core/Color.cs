﻿using System;

namespace Das.Views
{
    public class Color : IEquatable<Color>
    {
        public byte A { get; }
        
        public byte B { get; }
        
        public byte R { get; }

        public byte G { get; }

        private readonly Int32 _hash;

        public Color(byte a, byte r, byte g, byte b)
        {
            A = a;
            R = r;
            G = g;
            B = b;

            _hash = r + (g << 8) + (b << 16) + (a << 24);
        }

        public Color(byte r, byte g, byte b)
            : this(255,r,g,b)
        {
        }
        
        public static Color White => new Color(255, 255, 255);

        public static Color Red => new Color(255, 0, 0);

        public static Color Black => new Color(0,0,0);

        public static Color Transparent => new Color(0, 0, 0, 0);

        public static Color Orange => new Color(255, 127, 39);

        public bool Equals(Color other)
        {
            if (ReferenceEquals(other, null))
                return false;

            return other._hash == _hash;
        }

        public override int GetHashCode() => _hash;

        public override string ToString() => !Enum.IsDefined(typeof(Colors),_hash)
            ? $"{R}, {G}, {B} - {A}" : ((Colors)_hash).ToString();
    }
}
