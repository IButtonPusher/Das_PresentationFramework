﻿using System;

namespace Das.Views
{
    public class Brush : IEquatable<Brush>
    {
        public Brush(Color color)
        {
            Color = color;
        }

        public Color Color { get; }

        public virtual Boolean IsInvisible => Color.A == 0;

        public override string ToString() => "Brush: " + Color;

        public bool Equals(Brush other)
        {
            if (ReferenceEquals(null, other)) return false;
            if (ReferenceEquals(this, other)) return true;
            return Equals(Color, other.Color);
        }

        public override bool Equals(object obj)
        {
            if (obj is Brush b)
                return Equals(b);

            return false;
        }

        public override int GetHashCode() => (Color != null ? Color.GetHashCode() : 0);
    }
}
