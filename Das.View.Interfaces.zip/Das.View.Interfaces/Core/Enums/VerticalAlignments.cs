﻿using System;

namespace Das.Views
{
    public enum VerticalAlignments
    {
        Top,
        Bottom,
        Center,
        Stretch
    }
}
