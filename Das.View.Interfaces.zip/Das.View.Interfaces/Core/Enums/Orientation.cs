﻿using System;

namespace Das.Views
{
    public enum Orientations
    {
        Vertical,
        Horizontal,
        Both
    }
}
