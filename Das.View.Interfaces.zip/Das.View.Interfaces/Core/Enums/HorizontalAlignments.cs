﻿using System;

namespace Das.Views
{
    public enum HorizontalAlignments
    {
        Left,
        Right,
        Center,
        Stretch
    }
}
