﻿using System;

namespace Das.Views
{
    public class Thickness : Size, IDeepCopyable<Thickness>
    {
        public Thickness(double uniformLength)
        {
            Left = Right = Top = Bottom = uniformLength;
        }
        
        public Thickness(double left, double top, double right, double bottom)
        {
            Left = left;
            Top = top;
            Right = right;
            Bottom = bottom;
        }
      
        public double Left { get; }
        
        public double Top { get; }
        
        public double Right { get; }
        
        public double Bottom { get; }

        public override Double Width => Left + Right;

        public override Double Height => Top + Bottom;

        public static Thickness operator +(Thickness size, Thickness margin)
        {
            if (margin == null)
                return size.DeepCopy();

            return new Thickness(size.Left + margin.Left, margin.Top + size.Top,
                margin.Right + size.Right, margin.Bottom + size.Bottom);
        }

        public new Thickness DeepCopy() => new Thickness(Left, Top, Right, Bottom);
    }
}
