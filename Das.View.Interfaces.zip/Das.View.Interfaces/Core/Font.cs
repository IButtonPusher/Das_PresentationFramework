﻿using System;

namespace Das.Views
{
	public class Font : IEquatable<Font>
    {
        public Font(double size, string familyName, FontStyle fontStyle)
        {
            Size = size;
            FamilyName = familyName;
            FontStyle = fontStyle;
        }

        public Double Size { get; }

        public String FamilyName { get; }

        public FontStyle FontStyle { get; }

        public bool Equals(Font other)
        {
            if (ReferenceEquals(other, null))
                return false;

            if (Math.Abs(other.Size - Size) > 0.0001)
                return false;

            if (other.FontStyle != FontStyle)
                return false;

            return other.FamilyName.Equals(FamilyName, StringComparison.Ordinal);
        }


        public override int GetHashCode() => Convert.ToInt32(Size) +
            ((Int32)FontStyle << 8) + (FamilyName.GetHashCode() << 11);

        public override string ToString() => $"{FamilyName} {FontStyle}: {Size}";
    }
}
