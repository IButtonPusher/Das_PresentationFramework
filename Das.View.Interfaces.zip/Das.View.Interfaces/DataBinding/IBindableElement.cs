﻿using System;

namespace Das.Views
{
    public interface IBindableElement : IVisualElement
    {
        Object GetBoundValue(Object dataContext);

        void InvalidateBinding(Object dataContext);
    }

    public interface IBindableElement<out T> : IBindableElement
    {
        new T GetBoundValue(Object dataContext);
    }
}
