﻿using System;

namespace Das.Views.DataBinding
{
    public interface IDataBinding<out T> : IDataBinding
    {
        T GetValue(Object dataContext);

        T GetLastValue();
    }

    public interface IDataBinding
    {
        Object DataContext { get; set; }

        Object GetBoundValue(Object dataContext);

        Object GetLastBoundValue();
    }
}
