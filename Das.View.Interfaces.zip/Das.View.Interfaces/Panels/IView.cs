﻿using System;

namespace Das.Views
{
    public interface IView<T> : IContentContainer
    {
        IStyleContext StyleContext { get; }
    }
}
