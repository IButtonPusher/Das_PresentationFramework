﻿using System;

namespace Das.Views
{
    public interface ISequentialPanel : IVisualContainer
    {
        Orientations Orientation { get; set; }
    }
}
