﻿using System;
using System.Collections.Generic;

namespace Das.Views
{
    public interface IVisualContainer : IVisualElement, IBindableElement
    {
        IEnumerable<IVisualElement> Children { get; }

        void AddChild(IVisualElement element);

        void AddChildren(params IVisualElement[] elements);
    }
}
