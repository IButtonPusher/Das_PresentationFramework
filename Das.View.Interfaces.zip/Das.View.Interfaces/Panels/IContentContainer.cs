﻿using System;

namespace Das.Views
{
    public interface IContentContainer : IVisualElement
    {
        IVisualElement Content { get; set; }
    }
}
