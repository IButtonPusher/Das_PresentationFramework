﻿using System;

namespace Das.Views
{
    public interface IMeasureContext : IVisualContext
    {
        Size MeasureString(String s, Font font);

        Size MeasureImage(IImage img);

        Size MeasureElement(IVisualElement element, Size availableSpace);

        Size GetLastMeasure(IVisualElement element);
    }
}
