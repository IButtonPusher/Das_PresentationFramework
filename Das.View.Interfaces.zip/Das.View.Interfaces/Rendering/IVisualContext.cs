﻿using System;

namespace Das.Views
{
    public interface IVisualContext : IStyleProvider
    {
        Double ZoomLevel { get; }

        IStyle GetStyleForElement(IVisualElement element);

        T GetDataContext<T>(IBindableElement<T> element);
    }
}
