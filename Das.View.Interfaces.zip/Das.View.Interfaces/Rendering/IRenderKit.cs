﻿using System;

namespace Das.Views
{
    public interface IRenderKit
    {
    }
}
