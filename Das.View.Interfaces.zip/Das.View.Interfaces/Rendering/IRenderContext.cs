﻿using System;

namespace Das.Views
{
    public interface IRenderContext : IVisualContext
    {
        void DrawString(string s, Font font, Brush brush, Point location);

        void DrawImage(IImage img, Rectangle rect);

        void DrawLine(Pen pen, Point pt1, Point pt2);

        void FillRect(Rectangle rect, Brush brush);

        /// <summary>
        /// Returns the actual rectangle occupied by the element, including borders etc
        /// </summary>        
        Rectangle DrawElement(IVisualElement element, Rectangle rect);
    }
}
