﻿using System;

namespace Das.Views
{
    public interface IVisualRenderer
    {
        Size Measure(Size availableSpace, IMeasureContext measureContext);

        void Arrange(Size availableSpace, IRenderContext renderContext);
    }
}
